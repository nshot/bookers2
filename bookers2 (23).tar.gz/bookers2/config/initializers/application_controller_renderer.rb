# Be sure to restart your server when you modify this file.
Refile.secret_key = '1656b82daa20c473c1649ac02a5e64923c1572da1fe4dae977ffddfd5e653c35e1f143042cd6d01a486687c666f5e4d8d6d05ca4c370c9de305e18b01eb55aba'
# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
